package mathmedics.member;//package mathmedics.member;
//
//import java.util.ArrayList;
//
//public class SubClass {
//
//    public SubClass() {
//        ArrayList<Student> Arraystudent = new ArrayList<Student>();
//    }
//}
